ASSIGNMENT 2 for C++ PROGRAMMEERMETHODEN
    by Tim Müller (11774606)

For easy compilation, I have attached a Makefile to compile the file. Simply
run 'make' or 'make all' to compile the binary, which will be put in
bin/linux/MyCompress.

Running 'make clean' will cause all binaries to be deleted again.
